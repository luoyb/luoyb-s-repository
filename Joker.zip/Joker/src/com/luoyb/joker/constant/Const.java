package com.luoyb.joker.constant;

public class Const {

	// M系统的Id和token
	public static String mSysId = "";
	public static String mToken = "";

}
