package com.luoyb.joker.constant;

/**
 * 豌豆荚广告相关配置信息
 * 
 * @author luoyb
 * 
 */
public class WdjAdConst {

	// 豌豆荚广告的appid
	public static final String APP_ID = "100043510";
	// 豌豆荚广告的secretkey
	public static final String SECRET_KEY = "297fd1105b04acedd1bd3a020dd11105";
	// 豌豆荚广告位
	public static final String BANNER_AD_PLACE_ID_01 = "a93ed415e2edb8535628f19b5f200f4e";
	public static final String BANNER_AD_PLACE_ID_02 = "077bd1ce182f2abaeaaba02595c9eb04";
	public static final String BANNER_AD_PLACE_ID_03 = "f9d19011abde5ee1b4c167a0c8611b08";

}
