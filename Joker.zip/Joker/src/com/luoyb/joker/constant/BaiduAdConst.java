package com.luoyb.joker.constant;

/**
 * 百度广告相关配置信息
 * 
 * @author luoyb
 * 
 */
public class BaiduAdConst {

	// 百度广告的appid
	public final static String APP_SID = "e8372c93";
	// 百度广告位ID
	public final static String BANNER_AD_PLACE_ID = "2793929";

}
